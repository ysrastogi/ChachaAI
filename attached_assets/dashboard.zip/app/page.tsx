"use client"

import Dashboard from "../dashboard"

export default function SyntheticV0PageForDeployment() {
  return <Dashboard />
}